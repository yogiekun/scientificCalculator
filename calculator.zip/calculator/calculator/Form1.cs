﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    
    public partial class Form1 : Form
    {
        double result;
        string operation;
        double firstNumber;
        bool operatorClick = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "0" || operatorClick)
                textBox2.Clear();

            operatorClick = false;
            Button button = (Button)sender;
            if (button.Text == ".")
            {
                if(!textBox2.Text.Contains("."))
                    textBox2.Text += button.Text;
            }
            else
            {
                textBox2.Text += button.Text;
            }           
        }

        private void Button32_Click(object sender, EventArgs e)
        {
            int index = textBox2.Text.Length;
            index--;
            textBox2.Text = textBox2.Text.Remove(index);
            if (textBox2.Text == string.Empty)
            {
                textBox2.Text = "0";
            }
        }

        private void Button19_Click(object sender, EventArgs e)
        {
            textBox2.Text = "0";
        }

        private void Button22_Click(object sender, EventArgs e)
        {
            result = double.Parse(textBox2.Text);
            result = result * -1;
            textBox2.Text = result.ToString();
        }

        private void Button15_Click(object sender, EventArgs e)
        {
            firstNumber = double.Parse(textBox2.Text);
            Button btn = (Button)sender;
            operation = btn.Text;
            operatorClick = true;
        }

        private void Button14_Click(object sender, EventArgs e)
        {
            switch(operation)
            {
                case "+":
                    textBox2.Text = (firstNumber + double.Parse(textBox2.Text)).ToString();
                     break;

                case "-":
                    textBox2.Text = (firstNumber - double.Parse(textBox2.Text)).ToString();
                    break;

                case "x":
                    textBox2.Text = (firstNumber * double.Parse(textBox2.Text)).ToString();
                    break;

                case "/":
                    textBox2.Text = (firstNumber / double.Parse(textBox2.Text)).ToString();
                    break;

                case "EXP":
                    double pow = double.Parse(textBox2.Text);
                    double ans = Math.Exp(pow * Math.Log(firstNumber * 4));
                    textBox2.Text = ans.ToString();
                    break;

                case "^":
                    textBox2.Text = Math.Pow(firstNumber, double.Parse(textBox2.Text)).ToString();
                    break;
            }
        }

        private void Button30_Click(object sender, EventArgs e)
        {
            double val = Math.PI;
            textBox2.Text = val.ToString();
        }

        private void Button24_Click(object sender, EventArgs e)
        {
            double val = double.Parse(textBox2.Text);
            val = Math.Log10(val);
            textBox2.Text = val.ToString();
        }

        private void Button27_Click(object sender, EventArgs e)
        {
            double val = double.Parse(textBox2.Text);
            val = Math.Sqrt(val);
            textBox2.Text = val.ToString();
        }

        private void Button18_Click(object sender, EventArgs e)
        {
            double val = double.Parse(textBox2.Text);
            val = Math.Sin(val);
            textBox2.Text = val.ToString();
        }

        private void Button21_Click(object sender, EventArgs e)
        {
            double val = double.Parse(textBox2.Text);
            val = Math.Cos(val);
            textBox2.Text = val.ToString();
        }

        private void Button23_Click(object sender, EventArgs e)
        {
            double val = double.Parse(textBox2.Text);
            val = Math.Tan(val);
            textBox2.Text = val.ToString();
        }

        private void Button29_Click(object sender, EventArgs e)
        {
            double val = double.Parse(textBox2.Text);
            val = 1/val;
            textBox2.Text = val.ToString();
        }

        private void Button28_Click(object sender, EventArgs e)
        {
            double val = double.Parse(textBox2.Text);
            val = Math.Log(val);
            textBox2.Text = val.ToString();
        }

        

        private void Button17_Click(object sender, EventArgs e)
        {

        }

        private void Button17_Click_1(object sender, EventArgs e)
        {
            double val = double.Parse(textBox2.Text);
            val = val / 100;
            textBox2.Text = val.ToString();
        }

        private void Button20_Click(object sender, EventArgs e)
        {
            firstNumber = 0;
            textBox2.Text = "0";
        }
    }
}
